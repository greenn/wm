<?

$_versionDir = '/Snufkin-master/Snufkin-master/';
$_connectorFile1 = 'Snufkin.3.2.php';
$_connectorFile2 = 'Snufkin.3.3.php';

$_connectorFile = $_connectorFile2;
//$_connectorFile = $_connectorFile1;

$__DIR__ = dirname(__FILE__);
$_connectorPath = $__DIR__.$_versionDir.$_connectorFile;

include_once $_connectorPath;