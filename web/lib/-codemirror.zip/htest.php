<?
include_once $_SERVER['DOCUMENT_ROOT'].'/web/iq.inc';

d($_SERVER['QUERY_STRING']);
