<?

$phpcurlclassDir = dirname(__FILE__).'/php-curl-class-master/src/Curl';

require_once $phpcurlclassDir.'/CaseInsensitiveArray.php';
require_once $phpcurlclassDir.'/Curl.php';
require_once $phpcurlclassDir.'/MultiCurl.php';