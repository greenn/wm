<?

$kintVersionDir = 'kint-master';
$kintConnectorFile = 'Kint.class.php';

$__DIR__ = dirname(__FILE__);
$kintConnectorPath = $__DIR__.'/'.$kintVersionDir.'/'.$kintConnectorFile;

include_once $kintConnectorPath;


//addedTo { public static $aliases } (line: 61)

//d($kintConnectorPath);
if (!is_callable('dn')) {
    function dn(){
	    if (!headers_sent()) {
		    header('Content-Type: text/html; charset=utf-8');
	    }
        $args = func_get_args();
        call_user_func_array('d', $args);
    }
}
if (!is_callable('dextract')) {
	function dextract(){
		if (!headers_sent()) {
			header('Content-Type: text/html; charset=utf-8');
		}
		$args = func_get_args();
		call_user_func_array('d', $args);
	}
}

if (!is_callable('dx')) {
    function dx(){
        if (!headers_sent()) {
            header('Content-Type: text/html; charset=utf-8');
        }
        $args = func_get_args();
        call_user_func_array('d', $args);
        exit;
    }
}

if (!is_callable('dxextract')) {
	function dxextract(){
		if (!headers_sent()) {
			header('Content-Type: text/html; charset=utf-8');
		}
		$args = func_get_args();
		call_user_func_array('d', $args);
		exit;
	}
}

if (!is_callable('dc')) {
    function dc(){
        $args = func_get_args();
        ob_start();
        call_user_func_array('d', $args);
        $content = ob_get_clean();
        return $content;
    }
}

if (!is_callable('d1')) {
    function d1($argForD){
        //call_user_func_array('d', is_array($argForD) ? $argForD : array('d1' => $argForD ));
        $args = func_get_args();
        call_user_func_array('d', is_array($argForD) ? $argForD : array($args));
    }
}