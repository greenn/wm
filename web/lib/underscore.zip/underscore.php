<?

$_versionDir = 'Underscore.php-master';
$_connectorFile = 'underscore.php';

$__DIR__ = dirname(__FILE__);
$_connectorPath = $__DIR__.'/'.$_versionDir.'/'.$_connectorFile;

include_once $_connectorPath;