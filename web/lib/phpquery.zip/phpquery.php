<?



$phpqueryConnector = dirname(__FILE__).'/phpQuery-dir/phpQuery.php';

require_once $phpqueryConnector;