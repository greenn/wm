<? # https://github.com/parsecsv/parsecsv-for-php

$libDir = dirname(__FILE__).'/parsecsv-for-php-master';

require("$libDir/parsecsv.lib.php");