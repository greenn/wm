<? # https://github.com/nuovo/spreadsheet-reader

$libDir = dirname(__FILE__).'/spreadsheet-reader-master';


require("$libDir/php-excel-reader/excel_reader2.php");
require("$libDir/SpreadsheetReader.php");