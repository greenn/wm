<? # http://faisalman.github.io/simple-excel-php/

$libDir = dirname(__FILE__).'/faisalman-simple-excel-php-4a69805';

require("$libDir/excel_reader2.php");