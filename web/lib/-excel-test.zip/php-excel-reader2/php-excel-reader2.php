<? # https://code.google.com/archive/p/php-excel-reader2/

$libDir = dirname(__FILE__).'/php-excel-reader-2.23';

require("$libDir/excel_reader2.php");