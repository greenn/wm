<? # https://code.google.com/archive/p/php-spreadsheetreader/

$libDir = dirname(__FILE__).'/SpreadsheetReader';

require("$libDir/SpreadsheetReaderFactory.php");